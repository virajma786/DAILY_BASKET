package com.gms.grocessary_management_system.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gms.grocessary_management_system.dao.CustomerDao;
import com.gms.grocessary_management_system.entities.Customers;

@Transactional
@Service
public class CustomerServices {

    @Autowired
    private CustomerDao customerDao;
    public Customers editCustomer(Customers c) {
        Customers existingCustomer = customerDao.findById(c.getCustomerID())
            .orElseThrow(() -> new RuntimeException("Customer not found"));
    
        if (c.getCustomerName() != null) {
            existingCustomer.setCustomerName(c.getCustomerName());
        }
        if (c.getEmail() != null) {
            existingCustomer.setEmail(c.getEmail());
        }
        if (c.getPassword() != null) {
            existingCustomer.setPassword(c.getPassword());
        }
        if (c.getContactName() != null) {
            existingCustomer.setContactName(c.getContactName());
        }
        if (c.getAddress() != null) {
            existingCustomer.setAddress(c.getAddress());
        }
        if (c.getCity() != null) {
            existingCustomer.setCity(c.getCity());
        }
        if (c.getPostalCode() != null) {
            existingCustomer.setPostalCode(c.getPostalCode());
        }
        if (c.getCountry() != null) {
            existingCustomer.setCountry(c.getCountry());
        }
        if (c.getPhone() != null) {
            existingCustomer.setPhone(c.getPhone());
        }
    
        return customerDao.save(existingCustomer);
    }
    
}


/*
 *   "Email": "asdf@abc.com",
    "Password": "adasdfdf",
    "ContactName": "ContactName",
    "Address": "Address",
    "City": "City",
    "PostalCode": "PostalCode",
    "Country": "Country",
    "Phone": "1234567890"
 */