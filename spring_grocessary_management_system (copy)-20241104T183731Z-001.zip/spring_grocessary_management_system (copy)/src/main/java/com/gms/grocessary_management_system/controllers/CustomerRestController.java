package com.gms.grocessary_management_system.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gms.grocessary_management_system.entities.Customers;
import com.gms.grocessary_management_system.services.CustomerServices;

@CrossOrigin
@RestController
public class CustomerRestController {
    
    @Autowired
    private CustomerServices customerServices;

    @PutMapping("/customer/edit/{id}")
    public String customerUpdate(@RequestBody Customers c, @PathVariable("id") int id) {
        System.out.println("customer id received for editing:   " + id);
        System.out.println("Received Customer: " + c.toString());
        c.setCustomerID(id);
        customerServices.editCustomer(c);

        return "success";
    }
    
}
