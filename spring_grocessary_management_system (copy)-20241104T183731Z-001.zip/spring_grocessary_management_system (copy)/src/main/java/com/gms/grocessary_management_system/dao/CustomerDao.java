package com.gms.grocessary_management_system.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gms.grocessary_management_system.entities.Customers;

public interface CustomerDao extends JpaRepository<Customers,Integer> 
{
    
}
