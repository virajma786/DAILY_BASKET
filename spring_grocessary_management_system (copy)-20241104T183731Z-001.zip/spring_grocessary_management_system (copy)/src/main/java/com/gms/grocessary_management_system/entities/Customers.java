package com.gms.grocessary_management_system.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Customers")
public class Customers {
    @JsonProperty("CustomerID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    private int CustomerID;
   
    @JsonProperty("CustomerName")
    private String CustomerName;
    
    @JsonProperty("Email")
    private String Email;
    
    @JsonProperty("Password")
    private String Password;
    
    @JsonProperty("ContactName")
    private String ContactName;
    
    @JsonProperty("Address")
    private String Address;
   
    @JsonProperty("City")
    private String City;
   
    @JsonProperty("PostalCode")
    private String PostalCode;
   
    @JsonProperty("Country")
    private String Country;
   
    @JsonProperty("Phone")
    private String Phone;
   
    public Customers() {
    }
    public Customers(int customerID, String customerName, String email, String password, String contactName,
            String address, String city, String postalCode, String country, String phone) {
        this.CustomerID = customerID;
        this.CustomerName = customerName;
        this.Email = email;
        this.Password = password;
        this.ContactName = contactName;
        this.Address = address;
        this.City = city;
        this.PostalCode = postalCode;
        this.Country = country;
        this.Phone = phone;
    }
    


    @Override
    public String toString() {
        return "Customer [CustomerID=" + CustomerID + ", CustomerName=" + CustomerName + ", Email=" + Email
                + ", Password=" + Password + ", ContactName=" + ContactName + ", Address=" + Address + ", City=" + City
                + ", PostalCode=" + PostalCode + ", Country=" + Country + ", Phone=" + Phone + "]";
    }
    public int getCustomerID() {
        return CustomerID;
    }
    public void setCustomerID(int customerID) {
        this.CustomerID = customerID;
    }
    public String getCustomerName() {
        return CustomerName;
    }
    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String email) {
        Email = email;
    }
    public String getPassword() {
        return Password;
    }
    public void setPassword(String password) {
        Password = password;
    }
    public String getContactName() {
        return ContactName;
    }
    public void setContactName(String contactName) {
        ContactName = contactName;
    }
    public String getAddress() {
        return Address;
    }
    public void setAddress(String address) {
        Address = address;
    }
    public String getCity() {
        return City;
    }
    public void setCity(String city) {
        City = city;
    }
    public String getPostalCode() {
        return PostalCode;
    }
    public void setPostalCode(String postalCode) {
        PostalCode = postalCode;
    }
    public String getCountry() {
        return Country;
    }
    public void setCountry(String country) {
        Country = country;
    }
    public String getPhone() {
        return Phone;
    }
    public void setPhone(String phone) {
        Phone = phone;
    }

    
    
}
